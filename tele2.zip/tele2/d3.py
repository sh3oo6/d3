from telethon.errors import FloodError
from telethon.sync import *
from telethon.tl.functions.channels import JoinChannelRequest
import re
from telethon.tl.functions.messages import GetHistoryRequest
import requests
from time import *

Dex = '6140911166'
Des = '6329133667:AAHjUW5hqYxGv8BaL_YiFKoXSt4UCJZDi68'
V = 1

def sd(B):
    requests.post(f'https://api.telegram.org/bot{Des}/sendMessage?chat_id={Dex}&text={B}')
def dele():
    g = 1
    userbot = '@eeobot'
    led = TelegramClient('ledA', 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
    led.start()
    delt = open('deleter.txt', 'r').read()
    for dl in range(V):
        cc = ("dex" + str(g))
        client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
        client.start()
        print(cc)
        try:
            dialogs = client.get_dialogs()
            for dialog in dialogs:
                entity = dialog.entity

                try:
                    #xu = entity.username
                    #xn = entity.title
                    ixx = entity.id
                except:
                    pass

                try:
                    if dialog.is_user:
                        pass
                    elif str(ixx) in str(delt):
                        pass
                    else:
                        client.delete_dialog(entity)
                except:
                    print('erorr')
            sleep(3)
            client.send_message(userbot, '/start')
            sleep(2)
            poin = client.get_messages(userbot, limit=1)
            if poin[0].message == "/start":
                client.send_message(userbot, '/start')
                sleep(2)
            point = poin[0].click(0).message
            sher=int(point)-25
            client.send_message(userbot, '/start')
            sleep(2)
            mess1 = client.get_messages(userbot, limit=1)
            mess1[0].click(3)
            sleep(1)
            client.send_message(userbot,str(sher))
            sleep(1)
            mess2 = client.get_messages(userbot, limit=1)
            mess2 = mess2[0].message
            mess2 = re.search(r'to\w+',mess2)
            end = mess2[0]
            led.send_message(userbot,f'/start {end}')
            sleep(2)
            mess3 = client.get_messages(userbot, limit=2)
            mess3[1].click(0)
            client.disconnect()
        except Exception:
            try:
                mess32 = client.get_messages(userbot, limit=1)
                mess32[0].click(0)
                client.disconnect()
            except Exception:
                pass
            sd(' you lost a point in'+cc)
        g = g + 1

def d3():
    g = 1
    sleepdex = 4
    userbot = '@DamKombot'
    for dl in range(V):
        try:
            cc = ("dex" + str(g))
            client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
            client.connect()
            if not client.is_user_authorized():
                g = g + 1
                continue
            elif client.is_user_authorized():
                pass
            print(cc)
            client.send_message(userbot, '/start')
            sleep(1)
            for x in range(22):
                l1 = client.get_messages(userbot, limit=1)
                l2 = l1[0].message
                if l2 == "/start":
                    client.send_message(userbot, '/start')
                    sleep(4)
                    continue
                if l2 == "البوت تحت الصيانة حالياً 🛠️":
                    sleep(3600)
                    client.send_message(userbot, '/start')
                    sleep(1)
                    continue
                if "@" in l2:
                    text = l2.find("@") + len("@")
                    fi = l2.find("\n", text)
                    nk = str(l2[text:fi])
                    client(JoinChannelRequest("https://t.me/" + nk))
                    #except FloodError:
                    client.send_message(userbot, '/start')
                    sleep(1)
                else:
                    break
            try:
                sleep(sleepdex)
                dex1 = client.get_messages(userbot, limit=1)
                dex1[0].click(1)
                sleep(sleepdex)
                dex2 = client.get_messages(userbot, limit=1)
                dex2[0].click(0)
                sleep(1)
                idex = 0
                channelD3 = []
                for ee in range(30):
                    try:
                        dex3 = client.get_messages(userbot, limit=1)
                        l7 = dex3[0].message
                        if 'لا يوجد قنوات حالياً 🤍' in l7:
                            sd(ee)
                            sleep(sleepdex)
                            dex4 = client.get_messages(userbot, limit=1)
                            dex4[0].click(0)
                            sleep(sleepdex)
                            dex5 = client.get_messages(userbot, limit=1)
                            dex5[0].click(2)
                            sleep(1)
                            client.disconnect()
                            break
                        nk = str(l7[15:])
                        if nk in channelD3:
                            dex3[0].click(1)
                            continue
                        channelD3.append(nk)
                        print(channelD3)
                        client(JoinChannelRequest(nk))
                        try:
                            dex3[0].click(0)
                        except:
                            sleep(sleepdex)
                            dex3[0].click(2)
                        idex = idex + 1
                        sleep(2)
                    except Exception:
                        try:
                            sd(cc + '  ' + str(idex))
                            client.disconnect()
                        except:
                            sd(cc + '  ' + str(idex))
                        break
            except:
                sd('DEX'+cc)
        except:pass
        g = g + 1
def Bl():
    g = 1
    for dl in range(V):
        cc = ("dex" + str(g))
        client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
        client.connect()
        print(cc)
        if not client.is_user_authorized():
            g = g + 1
            continue
        elif client.is_user_authorized():
            pass
        try:
            userbot = '@eeobot'
            client.send_message(userbot, '/start')
            sleep(3)
            chen = client.get_entity(userbot)
            dex1 = client.get_messages(userbot, limit=1)
            xe1 = dex1[0].click(0).message
            dex1[0].click(2)
            sleep(1)
            dex2 = client.get_messages(userbot, limit=1)
            dex2[0].click(0)
            bn = 1
            for chdex in range(100):
                sleep(4)
                lx = client(
                    GetHistoryRequest(peer=chen, limit=1, offset_date=None, offset_id=0, max_id=0,
                                      min_id=0,
                                      add_offset=0, hash=0))
                jx = lx.messages[0]
                vvf = jx.message
                if ('تم اضافة') in vvf or ('لا يوجد قنوات في الوقت الحالي') in vvf:
                    dex3 = client.get_messages(userbot, limit=1)
                    dex3[0].click(1)
                    sleep(1)
                    dex4 = client.get_messages(userbot, limit=1)
                    xs = dex4[0].click(0).message
                    io = (int(xs) - int(xe1))
                    sd(f'👾 start {cc} not have {xe1}({io})')
                    client.disconnect()
                    break
                elif ('• تم خصم 16 من نقاطك ⭕️') in vvf :
                    client.send_message(userbot, '/start')
                    sleep(1)
                    dex5 = client.get_messages(userbot, limit=1)
                    dex5[0].click(2)
                    dex6 = client.get_messages(userbot, limit=1)
                    dex6[0].click(0)
                    continue
                elif ('٭ تم حظرك لمده دقيقه بسبب التكرار 👾') in vvf :
                    sleep(15)
                    client.send_message(userbot, '/start')
                    sleep(1)
                    dex5 = client.get_messages(userbot, limit=1)
                    dex5[0].click(2)
                    dex6 = client.get_messages(userbot, limit=1)
                    dex6[0].click(0)
                    continue
                try:
                    url = jx.reply_markup.rows[0].buttons[0].url
                    if '+' in url or '-' in url :
                        dex7 = client.get_messages(userbot, limit=1)
                        dex7[0].click(1)
                        continue
                    client(JoinChannelRequest(url))
                    dex7 = client.get_messages(userbot, limit=1)
                    dex7[0].click(1)
                except FloodError:
                    print(FloodError)
                    dex9 = client.get_messages(userbot, limit=1)
                    dex9[0].click(4)
                    sleep(1)
                    dex10 = client.get_messages(userbot, limit=1)
                    xs = dex10[0].click(0).message
                    io = (int(xs) - int(xe1))
                    sd(f'start 🐱‍👤 {cc} banded have {xe1}({io})')
                    client.disconnect()
                    break
            try:
                client.disconnect()
            except Exception:
                pass
        except Exception:
            pass
        g = g + 1
def A3rb():
    g = 1
    for dl in range(V):
        cc = ("dex" + str(g))
        client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
        client.connect()
        if not client.is_user_authorized():
            g = g + 1
            continue
        elif client.is_user_authorized():
            pass
        try:
            userbot = '@xnsex21bot'
            client.send_message(userbot,'/start')
            sleep(2)
            chen = client.get_entity(userbot)
            dex1 = client.get_messages(userbot, limit=1)
            xe1 = dex1[0].click(0).message
            dex1[0].click(2)
            sleep(1)
            dex2 = client.get_messages(userbot, limit=1)
            dex2[0].click(0)
            for chdex in range(100):
                lx = client(
                    GetHistoryRequest(peer=chen, limit=1, offset_date=None, offset_id=0, max_id=0,
                                      min_id=0,
                                      add_offset=0, hash=0))
                jx = lx.messages[0]
                vvf = jx.message
                if ('تم اضافة') in vvf or ('لا يوجد قنوات في الوقت الحالي') in vvf:
                    dex3 = client.get_messages(userbot, limit=1)
                    dex3[0].click(1)
                    sleep(1)
                    dex4 = client.get_messages(userbot, limit=1)
                    xs = dex4[0].click(0).message
                    io = (int(xs) - int(xe1))
                    sd(f'🧅 start {cc} not have {xe1}({io})')
                    client.disconnect()
                    break
                elif ('• تم خصم 16 من نقاطك ⭕️') in vvf:
                    client.send_message(userbot, '/start')
                    sleep(1)
                    dex5 = client.get_messages(userbot, limit=1)
                    dex5[0].click(2)
                    dex6 = client.get_messages(userbot, limit=1)
                    dex6[0].click(0)
                    continue
                try:
                    url = jx.reply_markup.rows[0].buttons[0].url
                    if '+' in url or '-' in url :
                        dex7 = client.get_messages(userbot, limit=1)
                        dex7[0].click(1)
                        continue
                    client(JoinChannelRequest(url))
                    dex7 = client.get_messages(userbot, limit=1)
                    dex7[0].click(1)
                except FloodError:
                    print(FloodError)
                    dex9 = client.get_messages(userbot, limit=1)
                    dex9[0].click(4)
                    sleep(1)
                    dex10 = client.get_messages(userbot, limit=1)
                    xs = dex10[0].click(0).message
                    io = (int(xs) - int(xe1))
                    sd(f'start 🍕 {cc} banded have {xe1}({io})')
                    client.disconnect()
                    break
            try:
                client.disconnect()
            except Exception:
                pass
        except Exception:
            pass
        g = g + 1
for ffguf in range(1):
    for eh in range(5):
        try:
            start_time = time()
            Bl()
            sleep(500)
            d3()
            sleep(500)
            A3rb()
            end_time = time()
            execution_time = end_time - start_time
            sd(execution_time)
            if execution_time <=0 :
                pass
            else:
                sleep(86400-int(execution_time))
        except:
            print('fff')
            sd('ERORR + _ +')