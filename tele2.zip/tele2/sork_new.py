from telethon.sync import TelegramClient
import asyncio
from time import sleep
async def Add_NUMBER():
    iqthon = TelegramClient('dex1', 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
    await iqthon.connect()
    sleep(4)
    await iqthon.disconnect()
asyncio.run(Add_NUMBER())