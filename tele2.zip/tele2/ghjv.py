import requests

# تعيين عدد العملات المشفرة التي تريد طباعتها
top_n = 20

# عنوان API للحصول على أسعار العملات المشفرة من CoinMarketCap
api_url = "https://api.coinmarketcap.com/v2/ticker/?limit=" + str(top_n)


# إرسال طلب GET للحصول على بيانات الأسعار
response = requests.get(api_url)
data = response.json()
print(data)


# التحقق من أن الاستجابة ناجحة
if response.status_code == 200:
    # الحصول على البيانات للعملات المشفرة
    cryptocurrencies = data['data']

    # طباعة أسعار أعلى 20 عملة مشفرة
    for rank in range(1, top_n + 1):
        cryptocurrency = cryptocurrencies[str(rank)]
        name = cryptocurrency['name']
        symbol = cryptocurrency['symbol']
        price_usd = cryptocurrency['quotes']['USD']['price']
        print(f"{rank}. {name} ({symbol}): ${price_usd:.2f}")

else:
    print("فشل الاستجابة. الرجاء المحاولة مرة أخرى.")