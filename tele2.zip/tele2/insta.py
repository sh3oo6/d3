from instapy import InstaPy
from instapy import smart_run

# إعداد معلومات الاعتماد على حساب Instagram الخاص بك
username =  'ulllc'
password =  'Goodlook_22'

# إعداد عملية الإلغاء على Instagram
def unfollow_all():
    session = InstaPy(username=username, password=password, headless_browser=True)

    with smart_run(session):
        session.unfollow_users(amount=999, allFollowing=True, sleep_delay=60)

# تشغيل عملية إلغاء المتابعة
if True:
    unfollow_all()