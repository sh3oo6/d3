from telethon.errors import FloodError
from telethon.sync import *
from telethon.tl.functions.channels import JoinChannelRequest
import re
import requests
from time import *

Dex = '6140911166'
Des = '6622166945:AAGYoRMijhEgfaLcq1o8cRAcXUj3Fs6obRw'
userbot='@DamKombot'
V = 14

def sd(B):
    requests.post(f'https://api.telegram.org/bot{Des}/sendMessage?chat_id={Dex}&text={B}')
sleepdex=4

def sing():
    g = 81
    delt = open('deleter.txt', 'r').read()
    for dl in range(V):
        try:
            cc = ("dex" + str(g))
            client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
            client.start()
            try:
                dialogs = client.get_dialogs()
                for dialog in dialogs:
                    entity = dialog.entity
                    try:
                        # xu = entity.username
                        # xn = entity.title
                        ixx = entity.id
                    except:
                        pass
                    if dialog.is_user:
                        pass
                    elif str(ixx) in str(delt):
                        pass
                    else:
                        client.delete_dialog(entity)
            except Exception:
                pass
            print(cc)
            client.send_message(userbot, '/start')
            sleep(1)
            for x in range(22):
                l1 = client.get_messages(userbot, limit=1)
                l2 = l1[0].message
                if l2 == "/start":
                    client.send_message(userbot, '/start')
                    sleep(1)
                    continue
                if l2 == "البوت تحت الصيانة حالياً 🛠️":
                    sleep(3600)
                    client.send_message(userbot, '/start')
                    sleep(1)
                    continue
                if "@" in l2:
                    text = l2.find("@") + len("@")
                    fi = l2.find("\n", text)
                    nk = str(l2[text:fi])
                    client(JoinChannelRequest("https://t.me/" + nk))
                    #except FloodError:
                    client.send_message(userbot, '/start')
                    sleep(1)
                else:
                    break
            try:
                sleep(sleepdex)
                dex1 = client.get_messages(userbot, limit=1)
                dex1[0].click(1)
                sleep(sleepdex)
                dex2 = client.get_messages(userbot, limit=1)
                dex2[0].click(0)
                sleep(1)
                idex = 0
                for ee in range(30):
                    try:
                        dex3 = client.get_messages(userbot, limit=1)
                        l7 = dex3[0].message
                        if 'لا يوجد قنوات حالياً 🤍' in l7:
                            sleep(sleepdex)
                            dex4 = client.get_messages(userbot, limit=1)
                            dex4[0].click(0)
                            sleep(sleepdex)
                            dex5 = client.get_messages(userbot, limit=1)
                            dex5[0].click(2)
                            dex6 = client.get_messages(userbot, limit=1)
                            dex6 = dex6[0].message
                            if '🗃️ الحساب' in dex6:
                                sleep(sleepdex)
                                dex7 = client.get_messages(userbot, limit=1)
                                dex7[0].click(2)
                                sleep(1)
                                dex8 = client.get_messages(userbot, limit=1)
                                dex8 = dex8[0].message
                                regex1 = r'[1234567890]\w+'
                                she = re.findall(regex1, dex8)
                                sleep(sleepdex)
                                dex9 = client.get_messages(userbot, limit=1)
                                dex9[0].click(4)
                                sleep(1)
                                client.send_message(userbot, Dex)
                                sleep(1)
                                client.send_message(userbot, she[0])
                                sd(cc + '  ' + str(idex))
                                client.disconnect()
                            else:
                                sd(cc + '  ' + str(idex))
                                client.disconnect()
                            break
                        nk = str(l7[15:])
                        client(JoinChannelRequest(nk))
                        try:
                            dex3[0].click(0)
                        except:
                            sleep(sleepdex)
                            dex3[0].click(1)
                        idex = idex + 1
                        sleep(2)
                    except Exception:
                        try:
                            sd(cc + '  ' + str(idex))
                            client.disconnect()
                        except:
                            sd(cc + '  ' + str(idex))
                        break
            except:
                sd('DEX'+cc)
        except:pass
        g = g + 1
for ffguf in range(666):
    for eh in range(20):
        sing()
        sleep(1111)
    sd('finsh coding testIIIIIIIIIIIIIIIII')
def d3():
    g = 1
    userbot = '@DamKombot'
    for dl in range(V):
        cc = ("dex" + str(g))
        client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
        client.connect()
        print(cc)
        if not client.is_user_authorized():
            g = g + 1
            continue
        elif client.is_user_authorized():
            pass
        try:
            client.send_message(userbot, '/start')
            sleep(4)
            for x in range(22):
                l1 = client.get_messages(userbot, limit=1)
                l2 = l1[0].message
                if l2 == "/start":
                    client.send_message(userbot, '/start')
                    sleep(2)
                    continue
                if l2 == "البوت تحت الصيانة حالياً 🛠️":
                    sleep(3600)
                    client.send_message(userbot, '/start')
                    sleep(1)
                    continue
                if "@" in l2:
                    text = l2.find("@") + len("@")
                    fi = l2.find("\n", text)
                    nk = str(l2[text:fi])
                    client(JoinChannelRequest("https://t.me/" + nk))
                    client.send_message(userbot, '/start')
                    sleep(2)
                else:
                    break

            sleep(4)
            dex1 = client.get_messages(userbot, limit=1)
            dex1[0].click(1)
            sleep(3)
            dex5 = client.get_messages(userbot, limit=1)
            dex5 = dex5[0].click(2).message
            if 'طالب' in dex5:
                print('jj')
                sleep(3)
                dex12 = client.get_messages(userbot, limit=1)
                dex12[0].click(3)
                sleep(3)
                dex6 = client.get_messages(userbot, limit=1)
                dex6[0].click(3)
                sleep(3)
                fi = open('gift.txt', 'r+')
                lines = fi.readlines()
                gifts = []
                for line in lines:
                    gifts.append(line.strip())
                fi.close()
                fe = open('gift.txt', 'w')
                for gift in gifts:
                    x = gift.replace('\n', '')
                    client.send_message(userbot , x)
                    sleep(3)
                    dex8 = client.get_messages(userbot, limit=2)
                    dex8e = dex8[1].message
                    if 'تم اضافة' in dex8e:
                        fe.write(gift + '\n')
                        sleep(5)
                        client.send_message(userbot, '/start')
                        dex6 = client.get_messages(userbot, limit=1)
                        dex6[0].click(3)
                    elif 'الكود خطأ' in dex8[0].message:
                        client.send_message(userbot, '/start')
                        sleep(5)
                        dex6 = client.get_messages(userbot, limit=1)
                        dex6[0].click(3)
            elif 'لقد حصلت' in dex5 :
                dex6 = client.get_messages(userbot, limit=1)
                dex6[0].click(3)
                sleep(3)
                fi = open('gift.txt', 'r+')
                lines = fi.readlines()
                gifts = []
                for line in lines:
                    gifts.append(line.strip())
                fi.close()
                fe = open('gift.txt', 'w')
                for gift in gifts:
                    x = gift.replace('\n', '')
                    client.send_message(userbot, x)
                    sleep(3)
                    dex8 = client.get_messages(userbot, limit=2)
                    dex8e = dex8[1].message
                    if 'تم اضافة' in dex8e:
                        fe.write(gift + '\n')
                        sleep(5)
                        client.send_message(userbot, '/start')
                        dex6 = client.get_messages(userbot, limit=1)
                        dex6[0].click(3)
                    elif 'الكود خطأ' in dex8[0].message:
                        client.send_message(userbot, '/start')
                        sleep(5)
                        dex6 = client.get_messages(userbot, limit=1)
                        dex6[0].click(3)
            client.disconnect()
            g = g + 1
        except:pass
def d32():
    g = 1
    userbot = '@DamKombot'
    for dl in range(V):
        cc = ("dex" + str(g))
        client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
        client.connect()
        if not client.is_user_authorized():
            g = g + 1
            continue
        elif client.is_user_authorized():
            pass
        try:
            client.send_message(userbot, '/start')
            sleep(3)
            for x in range(22):
                l1 = client.get_messages(userbot, limit=1)
                l2 = l1[0].message
                if l2 == "/start":
                    client.send_message(userbot, '/start')
                    sleep(2)
                    continue
                if l2 == "البوت تحت الصيانة حالياً 🛠️":
                    sleep(3600)
                    client.send_message(userbot, '/start')
                    sleep(1)
                    continue
                if "@" in l2:
                    text = l2.find("@") + len("@")
                    fi = l2.find("\n", text)
                    nk = str(l2[text:fi])
                    client(JoinChannelRequest("https://t.me/" + nk))
                    client.send_message(userbot, '/start')
                    sleep(2)
                else:
                    break

            sleep(4)
            dex1 = client.get_messages(userbot, limit=1)
            dex1[0].click(1)
            sleep(3)
            dex5 = client.get_messages(userbot, limit=1)
            dex5 = dex5[0].click(2).message
            if 'طالب' in dex5:
                sleep(3)
                dex12 = client.get_messages(userbot, limit=1)
                dex12[0].click(3)
                sleep(3)
                dex6 = client.get_messages(userbot, limit=1)
                dex6[0].click(3)
                sleep(3)
                fi = open('gift.txt', 'r+')
                lines = fi.readlines()
                gifts = []
                for line in lines:
                    gifts.append(line.strip())
                fi.close()
                fe = open('gift.txt', 'w')
                for gift in gifts:
                    x = gift.replace('\n', '')
                    client.send_message(userbot , x)
                    sleep(5)
                    dex8 = client.get_messages(userbot, limit=2)
                    dex8e = dex8[1].message
                    if 'تم اضافة' in dex8e:
                        fe.write(gift + '\n')
                        sleep(5)
                        client.send_message(userbot, '/start')
                        dex6 = client.get_messages(userbot, limit=1)
                        dex6[0].click(3)
                    elif 'الكود خطأ' in dex8[0].message:
                        client.send_message(userbot, '/start')
                        sleep(5)
                        dex6 = client.get_messages(userbot, limit=1)
                        dex6[0].click(3)
            elif 'لقد حصلت' in dex5 :
                sleep(3)
                dex61= client.get_messages(userbot, limit=1)
                dex61[0].click(2)
                sleep(3)
                dex6 = client.get_messages(userbot, limit=1)
                dex6[0].click(3)
                sleep(3)
                fi = open('gift.txt', 'r+')
                lines = fi.readlines()
                gifts = []
                for line in lines:
                    gifts.append(line.strip())
                fi.close()
                fe = open('gift.txt', 'w')
                for gift in gifts:
                    x = gift.replace('\n', '')
                    client.send_message(userbot, x)
                    sleep(3)
                    dex8 = client.get_messages(userbot, limit=2)
                    dex8e = dex8[1].message
                    if 'تم اضافة' in dex8e:
                        fe.write(gift + '\n')
                        sleep(5)
                        client.send_message(userbot, '/start')
                        dex6 = client.get_messages(userbot, limit=1)
                        dex6[0].click(3)
                    elif 'الكود خطأ' in dex8[0].message:
                        client.send_message(userbot, '/start')
                        sleep(5)
                        dex6 = client.get_messages(userbot, limit=1)
                        dex6[0].click(3)
            client.send_message(userbot, '/start')
            sleep(3)
            dex82 = client.get_messages(userbot, limit=1)
            dex82 = dex82[0].message
            regex1 = r'[1234567890]\w+'
            she = re.findall(regex1, dex82)
            sleep(3)
            dex92 = client.get_messages(userbot, limit=1)
            dex92[0].click(4)
            sleep(1)
            client.send_message(userbot, Dex)
            sleep(1)
            client.send_message(userbot, she[0])
            client.disconnect()
            g = g + 1
        except:pass