from telethon.sync import TelegramClient , events
from telethon.tl.functions.channels import JoinChannelRequest
import re
import requests
from time import sleep
import asyncio

client = TelegramClient('sor', 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
client.start()

V = 97
userbot='@DamKombot'
Dex = '6140911166'
Des = '6312593326:AAHxQ-9-buwS6q70dCOvhKvkJaBWkzKZcZg'
def sd(B):
    requests.post(f'https://api.telegram.org/bot{Des}/sendMessage?chat_id={Dex}&text={B}')

@client.on(events.NewMessage(pattern=r'^dex', outgoing=True))
async def execute_script(event):
    message = event.message.message[4:]
    g = 1
    for ffguf in range(1000):
        F = ("dex" + str(g))
        try:
            client = TelegramClient(F, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
            await client.start()
            print(F)
            await client.send_message(userbot, '/start')
            sleep(3)
            for x in range(22):
                l1 = await client.get_messages(userbot, limit=1)
                l2 = l1[0].message
                if l2 == "/start":
                    await client.send_message(userbot, '/start')
                    sleep(1)
                    continue
                if l2 == "البوت تحت الصيانة حالياً 🛠️":
                    sd('X')
                rege = r'يجب'
                matches = re.search(rege, l2)
                if matches != None:
                    regex = r'[-+qwertyuiopasdfghjklzxcvbnmPOIUYTREWQASDFGHJKLZXCVBNM1234567890]\w+'
                    sht = re.findall(regex, l2)
                    print(sht)
                    if sht[1] == 'start':
                        try:
                            cx = "https://t.me" + sht[0]
                            print(cx)
                            await client(JoinChannelRequest(cx))
                        except Exception:
                            cx = "https://t.me/" + sht[0]
                            print(cx)
                            await client(JoinChannelRequest(cx))
                    elif sht[3] == 'start':
                        try:
                            c = "https://t.me" + sht[2]
                            print(c)
                            await client(JoinChannelRequest(c))
                        except Exception:
                            c = "https://t.me/" + sht[2]
                            print(c)
                            await client(JoinChannelRequest(c))
                    elif sht[4] == 'start':

                        try:
                            t = "https://t.me" + sht[2] + sht[3]
                            await client(JoinChannelRequest(t))
                        except Exception:
                            try:
                                t = "https://t.me/" + sht[2] + sht[3]
                                await client(JoinChannelRequest(t))
                            except Exception:
                                t = "https://t.me/" + sht[2] + '/' + sht[3]
                                await client(JoinChannelRequest(t))
                    else:
                        try:
                            r = "https://t.me" + sht[2] + sht[3] + sht[4]
                            await client(JoinChannelRequest(r))
                        except Exception:
                            try:
                                r = "https://t.me/" + sht[2] + sht[3] + sht[4]
                                await client(JoinChannelRequest(r))
                            except Exception:
                                r = "https://t.me/" + sht[2] + '/' + sht[3] + sht[4]
                                await client(JoinChannelRequest(r))
                                #########+___+########
                    await client.send_message(userbot, '/start')
                    sleep(1)
            mscsag38 =await client.get_messages(userbot, limit=1)
            await mscsag38[0].click(3)
            sleep(1)
            await client.send_message(userbot, message)
            sleep(2.5)
            mscsag44 = await client.get_messages(userbot, limit=2)
            m = mscsag44[1].message
            sd(F+' '+m)
            await client.disconnect()
        except:
            sd('erorr in ' + F)
        if int(g) == int(V):
            sd('com code')
            break
        else:
            g = g + 1
client.run_until_disconnected()