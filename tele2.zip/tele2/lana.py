import re
import requests
from telethon.sync import TelegramClient , events , types
from telethon import Button, errors
from time import sleep
import re
from telethon.sync import TelegramClient
from telethon.tl import functions, types
token ='6266260770:AAE41B4Gl-vHXQJ031Hs9lbO5WTY210YxaU'
s= 6140911166
bot = TelegramClient('lanabot' , 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841').start(bot_token=token)


@bot.on(events.NewMessage(pattern='ee'))
async def BotOnStaeert2(event):
    if event.sender_id == s:
        await event.delete()
        try:
            async with bot.conversation(event.chat_id, timeout=300) as conv:
                await conv.send_message('url?')
                url = await conv.get_response()
                url = url.text
                open('lana.txt' , 'w').write(url)
                await conv.send_message('Tm')
        except:pass

@bot.on(events.NewMessage(pattern='/start'))
async def BotOnwStart(event):
    id = event.sender_id
    url_channel = open('lana.txt', 'r').read()
    ch = 'lana_sexyly'
    url = f'https://api.telegram.org/bot{token}/getchatmember?chat_id=@{ch}&user_id={id}'
    req = requests.get(url)
    if id == s or 'member' in req.text or 'creator' in req.text or 'administartor' in req.text:
        buttons = [[Button.url("🥰", url_channel)]]
        await event.respond(f"Lana bot is the best\nYour id : {id}", buttons=buttons)
    else:
        await event.reply('لازم تشترك بالقناة اول شي')







bot.run_until_disconnected()